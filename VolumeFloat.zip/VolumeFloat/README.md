# Volume Float
Control Your Sound, Anytime!  —  Dev. By Tasdik Hasan

## APK banano (2 ta upay)

### Upay 1: GitHub diye (phone/PC jekono ta theke)
1. github.com e notun repository banan, ei folder er shob file upload korun
   (`.github` folder shoho).
2. Repository te **Actions** tab e jan -> **Build APK** -> **Run workflow**.
3. Build shesh hole (~3-5 min) oi run e dhukle **Artifacts -> VolumeFloat-apk** pabe.
   Zip khule `app-release.apk` phone e install korun.

### Upay 2: Android Studio diye
1. Android Studio te ei folder open korun.
2. **Build -> Build APK(s)** (ba release er jonno `gradle assembleRelease`).
3. APK pabe `app/build/outputs/apk/`.

## Install korar por
- "Unknown sources" allow korte hobe.
- App open -> boro button chapun -> "Grant Permission" -> "Display over other apps" on korun.
- Floating icon dekha dile oita e tap korun, drag kore jekhane khushi rakhun.
