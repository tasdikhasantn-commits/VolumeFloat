package com.tasdik.volumefloat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        @Volatile
        var running = false
        const val ACTION_STOP = "com.tasdik.volumefloat.STOP"
        private const val CHANNEL = "volume_float"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var am: AudioManager
    private var iconView: View? = null
    private var iconLp: WindowManager.LayoutParams? = null
    private var panelView: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var expanded = false
    private var levelTv: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (iconView == null) showIcon()
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        hidePanel()
        iconView?.let { runCatching { wm.removeView(it) } }
        iconView = null
        running = false
        super.onDestroy()
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Volume Float", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_volume)
            .setContentTitle("Volume Float is running")
            .setContentText("Floating volume icon is active")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Turn off", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIF_ID, n,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Floating icon ----------

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun showIcon() {
        val size = dp(52)
        val prefs = getSharedPreferences("vf", MODE_PRIVATE)
        val v = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#3A8DFF"), Color.parseColor("#5B4CFF"))
            ).apply { cornerRadius = dp(16).toFloat() }
            alpha = 0.92f
        }
        v.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_volume)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(8))
            y = prefs.getInt("y", dp(240))
        }
        iconLp = lp

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    } else {
                        togglePanel()
                    }
                }
            }
            true
        }
        iconView = v
        wm.addView(v, lp)
    }

    // ---------- Volume panel ----------

    private fun togglePanel() {
        if (panelView == null) showPanel() else hidePanel()
    }

    private fun showPanel() {
        expanded = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(18))
            background = rounded(Color.parseColor("#F00B1230"), 22, STROKE)
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) {
                    hidePanel(); true
                } else false
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(300), WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        panelView = root
        panelLp = lp
        buildPanel()
        wm.addView(root, lp)
    }

    private fun hidePanel() {
        panelView?.let { runCatching { wm.removeView(it) } }
        panelView = null
        panelLp = null
        levelTv = null
    }

    private fun relayout() {
        val p = panelView ?: return
        val lp = panelLp ?: return
        runCatching { wm.updateViewLayout(p, lp) }
    }

    private fun buildPanel() {
        val root = panelView ?: return
        root.removeAllViews()

        // Header: dev credit + close
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = DEV_TEXT
            setTextColor(MUTED)
            textSize = 11f
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { hidePanel() }
        })
        root.addView(header)

        root.addView(TextView(this).apply {
            text = "Volume"
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10))
        })

        if (!expanded) buildCompact(root) else buildExpanded(root)
    }

    private fun buildCompact(root: LinearLayout) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val level = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            text = percent(AudioManager.STREAM_MUSIC)
        }
        levelTv = level

        fun step(dir: Int) {
            runCatching { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0) }
            level.text = percent(AudioManager.STREAM_MUSIC)
        }
        row.addView(roundBtn("−") { step(AudioManager.ADJUST_LOWER) })
        row.addView(level, LinearLayout.LayoutParams(dp(90), WRAP_CONTENT))
        row.addView(roundBtn("+") { step(AudioManager.ADJUST_RAISE) })
        root.addView(row)

        root.addView(pill("More Options  ⌄") {
            expanded = true
            buildPanel()
            relayout()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) })
    }

    private fun buildExpanded(root: LinearLayout) {
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        list.addView(sliderRow("Media", AudioManager.STREAM_MUSIC))
        list.addView(sliderRow("Phone Call", AudioManager.STREAM_VOICE_CALL))
        list.addView(sliderRow("Alarm", AudioManager.STREAM_ALARM))
        list.addView(sliderRow("Notification", AudioManager.STREAM_NOTIFICATION))
        list.addView(sliderRow("Ringtone", AudioManager.STREAM_RING))
        list.addView(sliderRow("System", AudioManager.STREAM_SYSTEM))
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(pill("More Settings") {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_SOUND_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            hidePanel()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })

        root.addView(pill("Fewer Options  ⌃") {
            expanded = false
            buildPanel()
            relayout()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) })
    }

    private fun sliderRow(label: String, stream: Int): View {
        val max = am.getStreamMaxVolume(stream)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(4))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pct = TextView(this).apply { setTextColor(MUTED); textSize = 13f }
        top.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 15f
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        top.addView(pct)
        col.addView(top)

        val sb = SeekBar(this).apply {
            this.max = max
            progress = am.getStreamVolume(stream)
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
        }
        fun show() {
            val cur = am.getStreamVolume(stream)
            pct.text = if (max == 0) "0%" else "${cur * 100 / max}%"
            if (sb.progress != cur) sb.progress = cur
        }
        show()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                // May be blocked by Do Not Disturb or a minimum level; ignore silently.
                runCatching { am.setStreamVolume(stream, p, 0) }
                show()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        col.addView(sb, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return col
    }

    // ---------- UI helpers ----------

    private fun percent(stream: Int): String {
        val max = am.getStreamMaxVolume(stream)
        return if (max == 0) "0%" else "${am.getStreamVolume(stream) * 100 / max}%"
    }

    private fun rounded(color: Int, radiusDp: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun roundBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 28f
        gravity = Gravity.CENTER
        background = rounded(ACCENT, 32)
        layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        setOnClickListener { onClick() }
    }

    private fun pill(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = rounded(CARD, 14, ACCENT)
        setOnClickListener { onClick() }
    }
}
