package com.tasdik.volumefloat

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var powerBg: GradientDrawable
    private lateinit var statusTv: TextView
    private lateinit var hintTv: TextView
    private lateinit var floatValue: TextView
    private lateinit var permValue: TextView
    private var pendingStart = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        if (pendingStart) {
            pendingStart = false
            if (Settings.canDrawOverlays(this)) startFloating()
        }
        refresh()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(BG)
            setPadding(dp(24), dp(20), dp(24), dp(20))
        }

        // Top: developer credit
        root.addView(TextView(this).apply {
            text = DEV_TEXT
            setTextColor(MUTED)
            textSize = 13f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Title
        root.addView(TextView(this).apply {
            text = "Volume Float"
            setTextColor(Color.WHITE)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "Control Your Sound, Anytime!"
            setTextColor(MUTED)
            textSize = 14f
            gravity = Gravity.CENTER
        })

        root.addView(spacer())

        // Big power button
        powerBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        val power = FrameLayout(this).apply {
            background = powerBg
            setOnClickListener { onPowerClick() }
        }
        power.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_power)
        }, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER))
        root.addView(power, LinearLayout.LayoutParams(dp(170), dp(170)))

        statusTv = TextView(this).apply {
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        }
        root.addView(statusTv)
        hintTv = TextView(this).apply {
            setTextColor(MUTED)
            textSize = 13f
            gravity = Gravity.CENTER
        }
        root.addView(hintTv)

        root.addView(spacer())

        // Status cards
        floatValue = TextView(this)
        permValue = TextView(this)
        root.addView(card("Floating Icon", floatValue))
        root.addView(card("Overlay Permission", permValue).also {
            (it.layoutParams as LinearLayout.LayoutParams).topMargin = dp(10)
        })

        // Footer
        root.addView(TextView(this).apply {
            text = DEV_TEXT
            setTextColor(MUTED)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
        return root
    }

    private fun spacer() = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
    }

    private fun card(title: String, value: TextView): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                setColor(CARD)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), STROKE)
            }
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        }
        row.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 15f
        }, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        value.textSize = 14f
        value.typeface = Typeface.DEFAULT_BOLD
        row.addView(value)
        return row
    }

    private fun refresh() {
        val on = FloatingService.running
        val granted = Settings.canDrawOverlays(this)
        val c = if (on) GREEN else ACCENT
        powerBg.setColor(if (on) Color.parseColor("#1A1ED67A") else Color.parseColor("#1A2F80FF"))
        powerBg.setStroke(dp(4), c)
        statusTv.text = if (on) "App is On" else "App is Off"
        statusTv.setTextColor(if (on) GREEN else Color.WHITE)
        hintTv.text = if (on) "Tap to turn off" else "Tap to turn on"
        floatValue.text = if (on) "Enabled" else "Off"
        floatValue.setTextColor(if (on) GREEN else RED)
        permValue.text = if (granted) "Granted" else "Not Granted"
        permValue.setTextColor(if (granted) GREEN else RED)
    }

    private fun onPowerClick() {
        if (FloatingService.running) {
            stopService(Intent(this, FloatingService::class.java))
            window.decorView.postDelayed({ refresh() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            showPermissionDialog()
            return
        }
        startFloating()
    }

    private fun showPermissionDialog() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Display Overlay Permission")
            .setMessage(
                "To show the floating icon on top of other apps, we need " +
                    "permission to display over other apps."
            )
            .setPositiveButton("Grant Permission") { _, _ ->
                pendingStart = true
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startFloating() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        window.decorView.postDelayed({ refresh() }, 400)
    }
}
