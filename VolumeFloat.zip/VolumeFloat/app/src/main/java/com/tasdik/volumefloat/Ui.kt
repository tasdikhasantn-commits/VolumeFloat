package com.tasdik.volumefloat

import android.graphics.Color

internal val BG = Color.parseColor("#0B1230")
internal val CARD = Color.parseColor("#141C3D")
internal val STROKE = Color.parseColor("#26335E")
internal val ACCENT = Color.parseColor("#2F80FF")
internal val GREEN = Color.parseColor("#1ED67A")
internal val RED = Color.parseColor("#FF5C6C")
internal val MUTED = Color.parseColor("#8FA0D0")
internal const val DEV_TEXT = "Dev. By Tasdik Hasan"
