# Volume Float

Floating volume control app (Kotlin, minSdk 26).

## Kivabe run korben
1. Android Studio (Koala ba notun) diye `VolumeFloat` folder ta open korun.
2. Gradle sync hote din (prothom bar internet lagbe).
3. Phone e run korun (USB debugging on kore) ba `Build > Build APK(s)`.

## Kivabe kaj kore
1. App khulle boro power button.
2. Button tap korle "Display over other apps" permission er dialog ashe.
3. "Grant Permission" -> Settings e `Volume Float` er toggle on korun -> back.
4. Permission dewar sathe sathe app on hoye jay, floating icon sob app er upor thake.
5. Icon drag kore jekhane khushi rakha jay.
6. Icon tap korle volume panel khole: `+` / `-` diye volume barano-komano, `X` diye panel bondho.
7. Power button abar tap korle floating icon bondho hoy.

## Structure
- `MainActivity.kt` - main screen, permission flow
- `FloatingService.kt` - foreground service, draggable icon, volume panel
