package com.example.volumefloat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL_ID = "volume_float_channel"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager

    private var iconView: View? = null
    private var iconParams: WindowManager.LayoutParams? = null
    private var panelView: View? = null

    private var currentStream: Int = AudioManager.STREAM_MUSIC

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        startForeground(NOTIF_ID, buildNotification())
        addFloatingIcon()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        removePanel()
        iconView?.let { runCatching { wm.removeView(it) } }
        iconView = null
        super.onDestroy()
    }

    // ---------- Floating icon ----------

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun addFloatingIcon() {
        val view = LayoutInflater.from(this).inflate(R.layout.floating_icon, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 400
        }

        val touchSlop = 10 * resources.displayMetrics.density
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var dragged = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) dragged = true
                    if (dragged) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) showPanel()
                    true
                }
                else -> false
            }
        }

        wm.addView(view, params)
        iconView = view
        iconParams = params
    }

    // ---------- Volume panel ----------

    private fun showPanel() {
        if (panelView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.floating_panel, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        val streamIcon = view.findViewById<ImageView>(R.id.streamIcon)
        val streamTitle = view.findViewById<TextView>(R.id.streamTitle)
        val levelText = view.findViewById<TextView>(R.id.levelText)
        val btnMore = view.findViewById<TextView>(R.id.btnMore)
        val moreContainer = view.findViewById<View>(R.id.moreContainer)

        val txtMusicLevel = view.findViewById<TextView>(R.id.txtMusicLevel)
        val txtAlarmLevel = view.findViewById<TextView>(R.id.txtAlarmLevel)
        val txtRingLevel = view.findViewById<TextView>(R.id.txtRingLevel)
        val txtCallLevel = view.findViewById<TextView>(R.id.txtCallLevel)

        fun refreshAll() {
            when (currentStream) {
                AudioManager.STREAM_ALARM -> {
                    streamIcon.setImageResource(R.drawable.ic_alarm)
                    streamTitle.text = "Alarm"
                }
                AudioManager.STREAM_RING -> {
                    streamIcon.setImageResource(R.drawable.ic_phone)
                    streamTitle.text = "Phone"
                }
                AudioManager.STREAM_VOICE_CALL -> {
                    streamIcon.setImageResource(R.drawable.ic_call)
                    streamTitle.text = "Call"
                }
                else -> {
                    streamIcon.setImageResource(R.drawable.ic_volume)
                    streamTitle.text = "Sound"
                }
            }
            levelText.text = getStreamPercent(currentStream)
            txtMusicLevel.text = getStreamPercent(AudioManager.STREAM_MUSIC)
            txtAlarmLevel.text = getStreamPercent(AudioManager.STREAM_ALARM)
            txtRingLevel.text = getStreamPercent(AudioManager.STREAM_RING)
            txtCallLevel.text = getStreamPercent(AudioManager.STREAM_VOICE_CALL)
        }

        fun changeStreamVolume(stream: Int, direction: Int) {
            currentStream = stream
            runCatching {
                audio.adjustStreamVolume(stream, direction, 0)
            }
            refreshAll()
        }

        refreshAll()

        view.findViewById<View>(R.id.btnUp).setOnClickListener {
            changeStreamVolume(currentStream, AudioManager.ADJUST_RAISE)
        }
        view.findViewById<View>(R.id.btnDown).setOnClickListener {
            changeStreamVolume(currentStream, AudioManager.ADJUST_LOWER)
        }

        btnMore.setOnClickListener {
            val isVisible = moreContainer.visibility == View.VISIBLE
            moreContainer.visibility = if (isVisible) View.GONE else View.VISIBLE
            btnMore.text = if (isVisible) "More Options ▾" else "Less Options ▴"
            refreshAll()
        }

        // Sound (Media) controls in More
        view.findViewById<View>(R.id.rowMusic).setOnClickListener {
            currentStream = AudioManager.STREAM_MUSIC
            refreshAll()
        }
        view.findViewById<View>(R.id.btnMusicUp).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE)
        }
        view.findViewById<View>(R.id.btnMusicDown).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER)
        }

        // Alarm controls in More
        view.findViewById<View>(R.id.rowAlarm).setOnClickListener {
            currentStream = AudioManager.STREAM_ALARM
            refreshAll()
        }
        view.findViewById<View>(R.id.btnAlarmUp).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_ALARM, AudioManager.ADJUST_RAISE)
        }
        view.findViewById<View>(R.id.btnAlarmDown).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_ALARM, AudioManager.ADJUST_LOWER)
        }

        // Phone (Ringtone) controls in More
        view.findViewById<View>(R.id.rowRing).setOnClickListener {
            currentStream = AudioManager.STREAM_RING
            refreshAll()
        }
        view.findViewById<View>(R.id.btnRingUp).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_RING, AudioManager.ADJUST_RAISE)
        }
        view.findViewById<View>(R.id.btnRingDown).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_RING, AudioManager.ADJUST_LOWER)
        }

        // Call controls in More
        view.findViewById<View>(R.id.rowCall).setOnClickListener {
            currentStream = AudioManager.STREAM_VOICE_CALL
            refreshAll()
        }
        view.findViewById<View>(R.id.btnCallUp).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_VOICE_CALL, AudioManager.ADJUST_RAISE)
        }
        view.findViewById<View>(R.id.btnCallDown).setOnClickListener {
            changeStreamVolume(AudioManager.STREAM_VOICE_CALL, AudioManager.ADJUST_LOWER)
        }

        view.findViewById<View>(R.id.btnClose).setOnClickListener { removePanel() }

        wm.addView(view, params)
        panelView = view
        iconView?.visibility = View.GONE
    }

    private fun removePanel() {
        panelView?.let { runCatching { wm.removeView(it) } }
        panelView = null
        iconView?.visibility = View.VISIBLE
    }

    private fun getStreamPercent(stream: Int): String {
        return runCatching {
            val cur = audio.getStreamVolume(stream)
            val max = audio.getStreamMaxVolume(stream)
            "${if (max > 0) cur * 100 / max else 0}%"
        }.getOrDefault("0%")
    }

    // ---------- Notification ----------

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Volume Float", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Volume Float is on")
            .setContentText("Tap to open the app")
            .setSmallIcon(R.drawable.ic_volume)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }
}
