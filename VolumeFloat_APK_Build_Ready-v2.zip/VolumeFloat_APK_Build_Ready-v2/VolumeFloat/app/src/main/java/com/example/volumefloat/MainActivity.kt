package com.example.volumefloat

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var powerButton: ImageView
    private lateinit var statusText: TextView
    private lateinit var floatState: TextView
    private lateinit var permState: TextView

    // user permission dite gele ar permission dewar por service auto start korar jonno
    private var pendingStart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        powerButton = findViewById(R.id.powerButton)
        statusText = findViewById(R.id.statusText)
        floatState = findViewById(R.id.floatState)
        permState = findViewById(R.id.permState)

        // Android 13+ e notification permission (foreground service er notification dekhanor jonno)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        powerButton.setOnClickListener { onPowerClicked() }
    }

    override fun onResume() {
        super.onResume()
        // Settings theke permission diye fire ashle auto on kore dibo
        if (pendingStart && Settings.canDrawOverlays(this)) {
            pendingStart = false
            startFloating()
        }
        refreshUi()
    }

    private fun onPowerClicked() {
        if (FloatingService.running) {
            stopFloating()
        } else if (!Settings.canDrawOverlays(this)) {
            showPermissionDialog()
        } else {
            startFloating()
        }
    }

    private fun showPermissionDialog() {
        AlertDialog.Builder(this, R.style.PermDialog)
            .setTitle("Display Overlay Permission")
            .setMessage(
                "To show the floating icon on top of other apps, we need " +
                    "permission to display over other apps."
            )
            .setPositiveButton("Grant Permission") { _, _ ->
                pendingStart = true
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startFloating() {
        FloatingService.running = true
        val intent = Intent(this, FloatingService::class.java)
        startForegroundService(intent)
        refreshUi()
    }

    private fun stopFloating() {
        FloatingService.running = false
        stopService(Intent(this, FloatingService::class.java))
        refreshUi()
    }

    private fun refreshUi() {
        val on = FloatingService.running
        val granted = Settings.canDrawOverlays(this)
        val green = getColor(R.color.green)
        val red = getColor(R.color.red_soft)

        powerButton.setBackgroundResource(if (on) R.drawable.bg_power_on else R.drawable.bg_power_off)
        powerButton.setColorFilter(if (on) green else getColor(R.color.blue_light))
        statusText.text = if (on) "App is On" else "Tap to Turn On"
        statusText.setTextColor(if (on) green else getColor(R.color.text_primary))

        floatState.text = if (on) "Enabled" else "Off"
        floatState.setTextColor(if (on) green else red)

        permState.text = if (granted) "Granted" else "Not Granted"
        permState.setTextColor(if (granted) green else red)
    }
}
